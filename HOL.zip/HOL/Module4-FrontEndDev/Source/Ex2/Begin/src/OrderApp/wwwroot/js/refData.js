System.register([], function (exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var RefData;
    return {
        setters: [],
        execute: function () {
            RefData = (function () {
                function RefData() {
                }
                return RefData;
            }());
            exports_1("default", RefData);
            RefData.COUNTRY_CODES = {
                Ireland: "ie",
                Spain: "es",
                "United Kingdom": "gb",
                France: "fr",
                Germany: "de",
                Sweden: "se",
                Italy: "it",
                Greece: "gr",
                Iceland: "is",
                Portugal: "pt",
                Malta: "mt",
                Norway: "no",
                Brazil: "br",
                Argentina: "ar",
                Colombia: "co",
                Peru: "pe",
                Venezuela: "ve",
                Uruguay: "uy"
            };
        }
    };
});
//# sourceMappingURL=refData.js.map