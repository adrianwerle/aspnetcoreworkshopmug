
ag-Grid Angular 2 Component
==============

This project contains the Angular 2 Component for use with ag-Grid.

Building
==============

To build:
- `npm install`
- `npm install gulp -g`
- `gulp`
