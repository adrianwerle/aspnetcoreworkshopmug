namespace ConsoleApplication.Entities
{
    public interface IEntityBase
    {
        int Id { get; set; }
    }
}